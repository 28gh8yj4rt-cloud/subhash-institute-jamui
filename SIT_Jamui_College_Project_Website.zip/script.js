const root = document.documentElement;
const colors = document.querySelectorAll('.color');

function setTheme(color) {
  root.style.setProperty('--primary', color);
  localStorage.setItem('sitTheme', color);
}
const saved = localStorage.getItem('sitTheme');
if (saved) setTheme(saved);

colors.forEach(btn => {
  btn.addEventListener('click', () => setTheme(btn.dataset.color));
});

const menuBtn = document.getElementById('menuBtn');
const navLinks = document.getElementById('navLinks');
menuBtn.addEventListener('click', () => navLinks.classList.toggle('show'));

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('show'));
});

document.getElementById('contactForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Thank you! Your message has been submitted for this project demo.');
  this.reset();
});
